module.exports = require('./lib/gravatar');
