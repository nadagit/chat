### 1.0.6
- Compatibility issue fix #6 
### 1.0.5
- Changed all tests to use mocha and should.js
### 1.0.4
- Test script to avoid global nodeunit - Fix #4
### 1.0.3
- Email trim (By Daniel Gasienica - @gasi) - Issue #2
### 1.0.2
- Using index.js as main in package.json. This is a standard in npm
### 1.0.1
- Defined lib/gravatar as main in package.json
### 1.0.0
- Can generate gravatar URL
- Basic test structure
- Initial documentation
